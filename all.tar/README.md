## Quick Start

1. Clone the repo

   ```
   $ git clone https://github.com/swells/js-example-fraud-score.git

   ```

2. Install the global requirements:

   ```
   $ npm install -g gulp bower browserify
   ```

3. Install the local requirements: 

   ```
   $ npm install
   ```

4. Run locally: 

   ```
   $ gulp
   ```

5.  View in browser at `http://localhost:9080`

